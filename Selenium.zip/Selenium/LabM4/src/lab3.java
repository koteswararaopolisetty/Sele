
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class lab3 {

	public static void main(String[] args) throws InterruptedException{
//		WebDriver driver=new FirefoxDriver();
//
//		driver.get("http://demo.opencart.com/");
//		driver.manage().window().maximize();
//		String pageTitle=driver.getTitle();
//		System.out.println("Page title is: "+pageTitle);
//		if(pageTitle.equals("Your Store"))
//		{
//			System.out.println("Expected title is present");
//		}
//		else
//		{
//		System.out.println("Expected title is not present");
//		}
//		
//		driver.findElement(By.className("caret")).click();
//		
////		String url = "https://demo.opencart.com/index.php?route=account/register";
////		driver.get(url);
//		//above or below one
//		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
		
		WebDriver driver=new FirefoxDriver();

		driver.get("http://demo.opencart.com/");
		
		Thread.sleep(1000);
		driver.manage().window().maximize();
		Thread.sleep(1000);
		String Title = "Your Store";
		String GetTitle = driver.getTitle();
		System.out.println("Assertion starts here...");
		Assert.assertEquals(Title, GetTitle);
		Thread.sleep(1000);
	driver.findElement(By.className("dropdown")).click();
	Thread.sleep(1000);

	driver.findElement(By.xpath("html/body/nav/div/div[2]/ul/li[2]/ul/li[1]")).click();
	
//Select drpCity = new Select(driver.findElement(By.className("dropdown")));
//	   drpCity.selectByVisibleText("Register");
//			Thread.sleep(2000);
		String Title1 = "Register Account";
		String GetTitle2 = driver.getTitle();
		System.out.println("Assertion 2 starts here");
		Assert.assertEquals(Title1, GetTitle2);
		Thread.sleep(1000);
        driver.findElement(By.id("input-firstname")).sendKeys("Asdopasda");
        Thread.sleep(1000);
    	driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div/input[2]")).click();
 
    	        
        driver.findElement(By.id("input-lastname")).sendKeys("jkkjhkkhkjh");
        Thread.sleep(2000);
        
        driver.findElement(By.id("input-email")).sendKeys("sdzjkhjks@gmail.com");
        Thread.sleep(2000);
        
        driver.findElement(By.id("input-telephone")).sendKeys("95483456465");
        Thread.sleep(2000);
		
        driver.findElement(By.id("input-password")).sendKeys("954834564615");
        Thread.sleep(2000);
        
        driver.findElement(By.id("input-confirm")).sendKeys("954834564615");
        Thread.sleep(2000);
		
        
  List<WebElement> radioElem = driver.findElements(By.name("newsletter"));
        
        for(WebElement webElement : radioElem)
        {
        		String radioSelection;
        		radioSelection = webElement.getAttribute("value").toString();
        		if(radioSelection.equals("1"))
        		{
        			webElement.click();
        		}
        		        	    			
        		try
        		{
        			Thread.sleep(500);
        		}
        		catch(InterruptedException ex)
        		{
        			System.out.println(ex.getMessage());
        		}	
        }
        
        List<WebElement> checkElem = driver.findElements(By.name("agree"));
        for(WebElement webElement : checkElem)
        {
        		String checkSelection;
        		checkSelection = webElement.getAttribute("value").toString();
        		if(checkSelection.equals("1"))
        		{
        			webElement.click();
        		}
        		        	    			
        		try
        		{
        			Thread.sleep(500);
        		}
        		catch(InterruptedException ex)
        		{
        			System.out.println(ex.getMessage());
        		}	
        }
        
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div/input[2]")).click();
		
		
		driver.findElement(By.className("dropdown")).click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("html/body/nav/div/div[2]/ul/li[2]/ul/li[2]/a")).click();
		
		

		
		
	}

}
